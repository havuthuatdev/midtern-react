import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Room from './resource/Room.js';
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  products = [];//tao mang rong
  // count = 1;
  constructor(props) {
    super(props);
    this.state = {
      // num: this.count,
      name: "",
      soluong : "",
      price: "",
      kichthuoc: "",
    };
    if (localStorage.getItem("product")) {
      this.products = [JSON.parse(localStorage.getItem("product"))][0];
    }

    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleChangeSoluong = this.handleChangeType.bind(this);
    this.handleChangePrice = this.handleChangePrice.bind(this);
    this.handleChangeKichthuoc = this.handleChangeQuantity.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }
  Message(){
    alert("thank you your order!")
  }

  handleChangeName(event) {
    this.setState({ name: event.target.value });
  }
  handleChangePrice(event) {
    this.setState({ soluong: event.target.value });
  }
  handleChangeType(event) {
    this.setState({ price: event.target.value });
  }
  handleChangeQuantity(event) {
    this.setState({ kichthuoc: event.target.value })
  }
  handleDelete = (index) => {
    this.products.splice(index, 1);
    this.saveLocal();
    window.location.reload(true);
    alert("Removed!");
  };
  saveLocal() {
    localStorage.setItem("product", JSON.stringify(this.products));
  }
  handleSubmit = () => {
    if (document.getElementById("submit").value == "") {
      if (JSON.parse(localStorage.getItem("product")) == null) {
        this.products.push(this.state);
      } else {
        this.products = [JSON.parse(localStorage.getItem("product"))][0];
        this.products.push(this.state);
      }
      this.count++;
      alert("Added!");
    } else {
      this.products[document.getElementById("submit").value] = this.state;
      alert("Edited!");
    }
    this.saveLocal();
    window.location.reload(true);
  };
  handleEdit = (product, index) => {
    this.setState(product);
    document.getElementById("name").value = product.name;
    document.getElementById("soluong").value = product.soluong;
    document.getElementById("price").value = product.price;
    document.getElementById("kichthuoc").value = product.kichthuoc;
    document.getElementById("submit").value = index;
  };
  render() {
    const products = this.products.map((product, index) => (
      <tr>
        <td>{index+1}</td>
        <td>{product.name}</td>
        {/* <td>
          <img src={"images/" + product.avatar} className="rounded-circle col-md-3"/>
        </td> */}
        <td>{product.soluong}</td>
        <td>{product.price}</td>
        <td>{product.kichthuoc}</td>
        <td>
          <div className="btn-group">
          <button className="btn btn-outline-danger" onClick={() => this.handleDelete(index)}>
            Delete
          </button>
          <button
            className="btn btn-outline-success" onClick={() => this.handleEdit(product,index)}
          >
            Edit
          </button>
          </div>
        </td>
      </tr>
    ));
  return (
    <div>
        <div className="container">
      <div class="row">
        {Room.map((value) => (
          <div className="col-md-6 col-lg-4 g-mb-30">
            <img src={value.image} />
            <br />
            <b>{value.name}</b>
            <div className="cart-detail">
              <div className="type">
                <p>PHÒNG</p>
                <p>{value.typeroom}</p>
              </div>
              <hr />
              <div className="num">
                <p>CHỖ NGHỈ</p>
                <p>{value.number + " Người lớn"}</p>
              </div>
              <hr />
              <div className="area">
                <p>KÍCH THƯỚC</p>
                <p>{value.area + "m2"}</p>
              </div>
              <hr />
              <div className="price">
                <p>GIÁ PHÒNG</p>
                <p>{value.price + ".vnđ"}</p>
              </div>
              <div className="oldprice">
                <p>GIÁ CU</p>
                <p>{value.oldprice + ".vnđ"}</p>
              </div>
              <div className="button">
                XEM
      <br></br>
                <button onClick = {this.Message}>Dat phong</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
    {/* -------------------- */}
    <div className="container">
        <div className="lg-col-12">
          <div className="lg-col-6">
            <form onSubmit={this.handleSubmit} className="">
              <div>
                {/* Hello world */}
                <div className="form-group">
                  <label htmlFor="name">Ten Phong</label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    aria-describedby="emailHelp"
                    placeholder="Enter name"
                    // value={this.state.name}
                    onChange={this.handleChangeName}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="name">So luong nguoi</label>
                  <input
                    type="text"
                    className="form-control"
                    id="soluong"
                    aria-describedby="emailHelp"
                    placeholder="Enter so luong"
                    // value={this.state.name}
                    onChange={this.handleChangeSoluong}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="name">Kich thuoc</label>
                  <input
                    type="text"
                    className="form-control"
                    id="price"
                    aria-describedby="emailHelp"
                    placeholder="Enter kich thuoc"
                    // value={this.state.name}
                    onChange={this.handleChangePrice}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="price">Price</label>
                  <input
                    type="text"
                    className="form-control"
                    id="kichthuoc"
                    aria-describedby="emailHelp"
                    placeholder="Enter price"
                    // value={this.state.price}
                    onChange={this.handleChangeKichthuoc}
                  />
                </div>
                <button id="submit" type="submit" className="btn btn-warning">
                  OK
                </button>
              </div>
            </form>
          </div>
          <div className="md-container p-md-3">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Name</th>
                  <th scope="col">So Luong</th>
                  <th scope="col">Gia</th>
                  <th scope="col">Kich Thuoc</th>
                </tr>
              </thead>
              <tbody>
                {products}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    
    
  )
}
}

export default App;
